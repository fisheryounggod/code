def hello():
    print("hello setuptools!")